from datetime import datetime

import grpc
from tqdm import tqdm

from ptrack import ptrack_pb2_grpc
from ptrack import ptrack_pb2

DATE_FORMAT = "%Y-%m-%d"
DT_FORMAT = "%Y-%m-%d %H:%M:%S"

__url = ""
channel = None
stub = None


def set_url(url):
    global __url, channel, stub

    __url = url
    creds = grpc.ssl_channel_credentials(root_certificates=None, private_key=None, certificate_chain=None)
    channel = grpc.secure_channel(__url, creds)
    stub = ptrack_pb2_grpc.PtrackServiceStub(channel)


def get_url():
    return __url


class IESOProjected(object):
    def __init__(self, date, created_at, version, demands):
        self.date = date
        self.created_at = created_at
        self.version = version
        self.demands = demands

    def __str__(self):
        out = f'{self.date.strftime(DATE_FORMAT)} v_{self.version} created at '
        out += f'{self.created_at.strftime(DT_FORMAT)} with demands [{self.demands[0]} ... {self.demands[11]}]'

        return out


class FiveMinDemand(object):
    def __init__(self, date, demands):
        self.date = date
        self.demands = demands

    def __str__(self):
        return f'{self.date.strftime(DT_FORMAT)} with demands [{self.demands[0]} ... {self.demands[11]}]'


class ActualDemand(object):
    def __init__(self, date, demand):
        self.date = date
        self.demand = demand

    def __str__(self):
        return f'{self.date.strftime(DT_FORMAT)} with demand {self.demand}'


class WeatherStats(object):
    def __init__(self, ws):
        self.date = datetime.strptime(ws.date, DT_FORMAT)
        self.pressure_station = ws.pressure_station
        self.pressure_sea = ws.pressure_sea
        self.wind_dir = ws.wind_dir
        self.wind_dir_10s = ws.wind_dir_10s
        self.wind_speed = ws.wind_speed
        self.wind_gust = ws.wind_gust
        self.relative_humidity = ws.relative_humidity
        self.dew_point = ws.dew_point
        self.temperature = ws.temperature
        self.wind_chill = ws.wind_chill
        self.humidex = ws.humidex
        self.visibility = ws.visibility
        self.health_index = ws.health_index
        self.cloud_cover4 = ws.cloud_cover4
        self.cloud_cover8 = ws.cloud_cover8
        self.cloud_cover10 = ws.cloud_cover10
        self.solar_radiation = ws.solar_radiation

    def __str__(self):
        return f'Date: \t\t\t{self.date.strftime(DT_FORMAT)}' \
               f'\nHumidex: \t\t{self.humidex}' \
               f'\nWind dir: \t\t{self.wind_dir}' \
               f'\nWind Gust: \t\t{self.wind_gust}' \
               f'\nDew Point: \t\t{self.dew_point}' \
               f'\nWind Chill: \t\t{self.wind_chill}' \
               f'\nWind Speed: \t\t{self.wind_speed}' \
               f'\nVisibility: \t\t{self.visibility}' \
               f'\nWind dir10s: \t\t{self.wind_dir_10s}' \
               f'\nTemperature: \t\t{self.temperature}' \
               f'\nHealth Index: \t\t{self.health_index}' \
               f'\nPressure Sea: \t\t{self.pressure_sea}' \
               f'\nCloud Cover4: \t\t{self.cloud_cover4}' \
               f'\nCloud Cover8: \t\t{self.cloud_cover8}' \
               f'\nCloud Cover10: \t\t{self.cloud_cover10}' \
               f'\nSolar radiation: \t{self.solar_radiation}' \
               f'\nPressure Station: \t{self.pressure_station}' \
               f'\nRelative Humidity: \t{self.relative_humidity}\n'


def __get__length(metadata):
    """extracts length from metadata"""
    for key, value in metadata:
        if key == "length":
            try:
                length = int(value)
                return length
            except ValueError:
                print("error while parsing length from metadata")

    return -1


def ieso_projected(start, end=None, progress=False):
    """ Returns ieso projected for the given interval
    :param start: start date, datetime object
    :param end: end date, datetime object
    :param progress: show progress bar or not
    :return: list of Projected objects
    """
    result = []

    if end is None:
        end = start

    try:
        req = ptrack_pb2.GetProjectedRequest()
        req.start_date = start.strftime(DT_FORMAT)
        req.end_date = end.strftime(DT_FORMAT)

        res = stub.GetProjected(req)
        length = __get__length(res.initial_metadata())

        if progress and length > 0:
            with tqdm(total=length, ascii=True, desc='Getting IESO Projected') as pbar:
                for r in res:
                    ip = IESOProjected(datetime.strptime(r.data.date, DT_FORMAT),
                                       datetime.strptime(r.data.created_at, DT_FORMAT),
                                       r.data.version, r.data.demands)
                    result.append(ip)
                    pbar.update(1)
        else:
            for r in res:
                ip = IESOProjected(datetime.strptime(r.data.date, DT_FORMAT),
                                   datetime.strptime(r.data.created_at, DT_FORMAT),
                                   r.data.version, r.data.demands)
                result.append(ip)
    except Exception as e:
        print("error in ieso_projected: \n", e)
        print(f'start date:\t{start.strftime(DT_FORMAT)}')
        print(f'end date:\t{end.strftime(DT_FORMAT)}')
        return []

    return result


def five_minute_demand(start, end=None, progress=False):
    """ Returns 5-minute demands for the given interval
    :param start: start date, datetime object
    :param end: end date, datetime object
    :param progress: show progress bar or not
    :return: list of FiveMinDemand objects
    """
    result = []

    if end is None:
        end = start

    try:
        req = ptrack_pb2.Get5MinDemandRequest()
        req.start_date = start.strftime(DT_FORMAT)
        req.end_date = end.strftime(DT_FORMAT)

        res = stub.Get5MinDemand(req)
        length = __get__length(res.initial_metadata())

        if progress and length > 0:
            with tqdm(total=length, ascii=True, desc='Getting 5-Minute Demands') as pbar:
                for r in res:
                    fd = FiveMinDemand(datetime.strptime(r.data.date, DT_FORMAT), r.data.demands)
                    result.append(fd)
                    pbar.update(1)
        else:
            for r in res:
                fd = FiveMinDemand(datetime.strptime(r.data.date, DT_FORMAT), r.data.demands)
                result.append(fd)
    except Exception as e:
        print("error in five_minute_demand: \n", e)
        print(f'start date:\t{start.strftime(DT_FORMAT)}')
        print(f'end date:\t{end.strftime(DT_FORMAT)}')
        return []

    return result


def actual_demand(start, end=None, progress=False):
    """ Returns actual demands for the given interval
    :param start: start date, datetime object
    :param end: end date, datetime object
    :param progress: show progress bar or not
    :return: list of ActualDemand objects
    """
    result = []

    if end is None:
        end = start

    try:
        req = ptrack_pb2.GetActualDemandRequest()
        req.start_date = start.strftime(DT_FORMAT)
        req.end_date = end.strftime(DT_FORMAT)

        res = stub.GetActualDemand(req)
        length = __get__length(res.initial_metadata())

        if progress and length > 0:
            with tqdm(total=length, ascii=True, desc='Getting Actual Demands') as pbar:
                for r in res:
                    ad = ActualDemand(datetime.strptime(r.data.date, DT_FORMAT), r.data.demand)
                    result.append(ad)
                    pbar.update(1)
        else:
            for r in res:
                ad = ActualDemand(datetime.strptime(r.data.date, DT_FORMAT), r.data.demand)
                result.append(ad)
    except Exception as e:
        print("error in actual_demand: \n", e)
        print(f'start date:\t{start.strftime(DT_FORMAT)}')
        print(f'end date:\t{end.strftime(DT_FORMAT)}')
        return []

    return result


def weather_stats(start, end=None, progress=False):
    """ Returns weather stats for the given interval
    :param start: start date, datetime object
    :param progress: show progress bar or not
    :param end: end date, datetime object
    :return: list of WeatherStats objects
    """
    result = []

    if end is None:
        end = start

    try:
        req = ptrack_pb2.GetWeatherStatsRequest()
        req.start_date = start.strftime(DT_FORMAT)
        req.end_date = end.strftime(DT_FORMAT)

        res = stub.GetWeatherStats(req)
        length = __get__length(res.initial_metadata())

        if progress and length > 0:
            with tqdm(total=length, ascii=True, desc='Getting Weather Stats') as pbar:
                for r in res:
                    ws = WeatherStats(r.data)
                    result.append(ws)
                    pbar.update(1)
        else:
            for r in res:
                ws = WeatherStats(r.data)
                result.append(ws)
    except Exception as e:
        print("error in weather_stats: \n", e)
        print(f'start date:\t{start.strftime(DT_FORMAT)}')
        print(f'end date:\t{end.strftime(DT_FORMAT)}')
        return []

    return result
